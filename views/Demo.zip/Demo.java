public class Demo{
    public static void main(String[] args) {
        int a=14,b=6;
        System.out.print((a+b+Math.abs(a-b))/2);
    }
}